<?php
	require("dbconnect.php");
	class User {
		//Atributos
		private $idUtilizador;
		private $NomeUtilizador;
		private $Email;
		private $Password;
		private $Perfil;

		//Acessores e Modificadores
		public function setIdUtilizador($value){
			$this->idUtilizador = $value;
		}

		public function getIdUtilizador(){
			return $this->idUtilizador;
		}

		public function setNomeUtilizador($value){
			$this->NomeUtilizador = $value;
		}

		public function getNomeUtilizador(){
			return $this->NomeUtilizador;
		}

		public function setEmail($value){
			$this->Email = $value;
		}

		public function getEmail(){
			return $this->Email;
		}

		public function setPassword($value){
			$this->Password = $value;
		}

		public function getPassword(){
			return $this->Password;
		}

		public function setPerfil($value){
			$this->Perfil = $value;
		}

		public function getPerfil(){
			return $this->Perfil;
		}

		public function verificaLogin() {
			require("dbconnect.php");

			$sql = "Select * FROM Utilizador WHERE NomeUtilizador = '" . $this->NomeUtilizador . "' and Password = '" . $this->Password . "'";

			// Preparação da instrução á BD
			$query = $connect->query($sql);
			// Execução da query na BD a gravar resultados numa varíavel
			$users = $query->fetchAll(PDO::FETCH_ASSOC);

			return $users;
		}

		public function createUser() {
			require("dbconnect.php");

			$sql = "INSERT INTO utilizador(NomeUtilizador, Email, Password, Perfil) VALUES ('" . $this->NomeUtilizador . "','" . $this->Email . "','" . $this->Password . "','" . $this->Perfil . "')";

			$connect->exec($sql);
		}

		public function deleteUser($idUtilizador) {
			require("dbconnect.php");

			$sql = "DELETE FROM utilizador WHERE idUtilizador = " . $idUtilizador;

			$connect->exec($sql);
		}
		
		public function listUser() {
			require("dbconnect.php");

			// Instrução SQL para ler todos os carros da BD
			$sql = "SELECT * FROM utilizador" ; 
			// Preparação da instrução á BD
			$query = $connect->query($sql);
			// Execução da query na BD a gravar resultados numa varíavel
			$users = $query->fetchAll(PDO::FETCH_ASSOC);

			// Devolver resultado 
			return $users;
		}

		public function editUser() {
			require("dbconnect.php");

			// Instrução SQL para registar o utilizador
			$sql = "UPDATE utilizador SET NomeUtilizador = '" . $this->NomeUtilizador . "', Email='" . $this->Email . "', Password='" . $this->Password . "', Perfil='" . $this->Perfil . "' WHERE idUtilizador =" . $this->idUtilizador;

			//Executar instrução SQL na base de dados
			$connect->exec($sql);
		}

		public function getById(){
			require("dbconnect.php");

			// Instrução SQL para selecionar dados da bd
			$sql = "SELECT * FROM utilizador WHERE idUtilizador =" . $this->idUtilizador;

			// Preparar instrução 
			$query = $connect->query($sql);

			// Executar a query e gravar resultados
			$user = $query->fetchAll(PDO::FETCH_ASSOC);

			// Retornar os dados
			return $user;
		}

		public function countUsers(){
			require("dbconnect.php");

			// Instrução SQL para selecionar dados da bd
			$sql = "SELECT COUNT(idUtilizador) AS total FROM utilizador";

			// Preparar instrução 
			$query = $connect->query($sql);

			// Executar a query e gravar resultados
			$user = $query->fetchAll(PDO::FETCH_ASSOC);

			// Retornar os dados
			return $user;
		}

		public function userPermission(){
			require("dbconnect.php");

			// Instrução SQL para selecionar dados da bd
			$sql = "SELECT * FROM utilizador WHERE Perfil = Administrador";

			// Preparar instrução 
			$query = $connect->query($sql);

			// Executar a query e gravar resultados
			$user = $query->fetchAll(PDO::FETCH_ASSOC);

			// Retornar os dados
			return $user;
		}
	}