<?php 
  $dsn = "mysql:host=localhost;dbname=bdfastorder";
  $user = "root";
  $passwd = "";
  $connect = new PDO($dsn, $user, $passwd);
?>